import { NotFoundContent } from "@/components/ui/error/not-found-content";

export default function NotFound() {
  return <NotFoundContent />;
}