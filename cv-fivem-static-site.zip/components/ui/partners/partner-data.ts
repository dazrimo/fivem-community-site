export const partnerLogos = [
  "https://cdn.prod.website-files.com/6257adef93867e50d84d30e2/6257d23c5fb25be7e0b6e220_Open%20Source%20Projects%20_%20Discord-7.svg", // Discord
  "https://cdn.worldvectorlogo.com/logos/twitch-blacklogo.svg", // Twitch
  "https://forum-cfx-re.akamaized.net/original/5X/a/5/b/6/a5b6d11f43e229d5cd9b22787969a7629a138391.png", // Rockstar Games
  "https://img.itch.zone/aW1nLzE4MzUyNzA4LnBuZw==/original/GauNfb.png", // Steam
  "https://assets.umod.org/images/icons/plugin/6541131274c81.png", // Tebex
];